package controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileInitializer {

    public static void initializeDataFiles() {
        File dataDir = new File("data");
        if (!dataDir.exists()) {
            dataDir.mkdirs();
            System.out.println("Ο φάκελος /data δημιουργήθηκε.");
        }

        createUsersFile();
        createCallsFile();
    }

    private static void createUsersFile() {
        File usersFile = new File("data/users.csv");
        if (!usersFile.exists()) {
            try (FileWriter writer = new FileWriter(usersFile)) {
                writer.write("admin;admin123;Διαχειριστής;0000000000\n");
                writer.write("testuser;1234;Γιώργος Τεστ;6999999999\n");
                System.out.println("Το αρχείο users.csv δημιουργήθηκε.");
            } catch (IOException e) {
                System.out.println("Σφάλμα δημιουργίας users.csv: " + e.getMessage());
            }
        }
    }

    private static void createCallsFile() {
        File callsFile = new File("data/calls.csv");
        if (!callsFile.exists()) {
            try (FileWriter writer = new FileWriter(callsFile)) {
                writer.write("1;Γιώργος Τεστ;6999999999;Φωτιά σε πάρκο;ΠΥΡΟΣΒΕΣΤΙΚΗ;PENDING;2025-05-22T14:30:00\n");
                System.out.println("Το αρχείο calls.csv δημιουργήθηκε.");
            } catch (IOException e) {
                System.out.println("Σφάλμα δημιουργίας calls.csv: " + e.getMessage());
            }
        }
    }
}

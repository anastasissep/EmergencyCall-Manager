package controller;

import model.EmergencyCall;
import model.ServiceType;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class Exporter {

    public static void exportToJson(List<EmergencyCall> calls, String filename) {
        try (FileWriter fw = new FileWriter(filename)) {
            fw.write("[\n");
            for (int i = 0; i < calls.size(); i++) {
                EmergencyCall c = calls.get(i);
                fw.write("  {\n");
                fw.write("    \"id\": " + c.getId() + ",\n");
                fw.write("    \"caller\": \"" + c.getCaller().getFullName() + "\",\n");
                fw.write("    \"phone\": \"" + c.getCaller().getPhoneNumber() + "\",\n");
                fw.write("    \"description\": \"" + c.getDescription().replace("\"", "\\\"") + "\",\n");
                fw.write("    \"services\": \"" + c.getServices().toString() + "\",\n");
                fw.write("    \"status\": \"" + c.getStatus() + "\",\n");
                fw.write("    \"timestamp\": \"" + c.getTimestamp() + "\"\n");
                fw.write("  }" + (i < calls.size() - 1 ? "," : "") + "\n");
            }
            fw.write("]");
            System.out.println("JSON export -> Ολοκληρώθηκε.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void exportToXml(List<EmergencyCall> calls, String filename) {
        try (FileWriter fw = new FileWriter(filename)) {
            fw.write("<calls>\n");
            for (EmergencyCall c : calls) {
                fw.write("  <call>\n");
                fw.write("    <id>" + c.getId() + "</id>\n");
                fw.write("    <caller>" + c.getCaller().getFullName() + "</caller>\n");
                fw.write("    <phone>" + c.getCaller().getPhoneNumber() + "</phone>\n");
                fw.write("    <description>" + c.getDescription() + "</description>\n");
                fw.write("    <services>" + c.getServices().toString() + "</services>\n");
                fw.write("    <status>" + c.getStatus() + "</status>\n");
                fw.write("    <timestamp>" + c.getTimestamp() + "</timestamp>\n");
                fw.write("  </call>\n");
            }
            fw.write("</calls>");
            System.out.println("XML export -> Ολοκληρώθηκε.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

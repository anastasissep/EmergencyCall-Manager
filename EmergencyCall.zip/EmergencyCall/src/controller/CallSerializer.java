package controller;

import model.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CallSerializer {
    public static EmergencyCall deserialize(String line) {
        try {
            String[] parts = line.split(";");
            // Προσοχή: εδώ απλώς δημιουργούμε "ψευδο" Citizen, αφού δεν έχουμε αποθηκευμένα username/password
            Citizen citizen = new Citizen("placeholder", "placeholder", parts[1], parts[2]);
            String description = parts[3];
            String[] servicesStr = parts[4].split(",");
            List<ServiceType> services = new ArrayList<>();
            for (String s : servicesStr) {
                services.add(ServiceType.valueOf(s));
            }
            EmergencyCall call = new EmergencyCall(citizen, description, services);
            call.setStatus(CallStatus.valueOf(parts[5]));
            // Η ημερομηνία/ώρα δεν επαναφέρεται στο αντικείμενο εδώ για απλότητα
            return call;
        } catch (Exception e) {
            System.out.println("Σφάλμα κατά την ανάγνωση κλήσης: " + line);
            return null;
        }
    }
}

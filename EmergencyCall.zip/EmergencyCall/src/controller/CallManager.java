package controller;

import model.EmergencyCall;
import model.ServiceType;
import model.CallStatus;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CallManager {
    private List<EmergencyCall> callList;

    public CallManager() {
        this.callList = new ArrayList<>();
    }

    public void addCall(EmergencyCall call) {
        callList.add(call);
    }

    public List<EmergencyCall> getAllCalls() {
        return callList;
    }

    public List<EmergencyCall> getCallsByService(ServiceType service) {
        List<EmergencyCall> filtered = new ArrayList<>();
        for (EmergencyCall call : callList) {
            if (call.getServices().contains(service) && call.getStatus() == CallStatus.PENDING) {
                filtered.add(call);
            }
        }
        return filtered;
    }

    public void markCallAsResolved(int id) {
        for (EmergencyCall call : callList) {
            if (call.getId() == id) {
                call.setStatus(CallStatus.RESOLVED);
                break;
            }
        }
    }

    public void sortCallsByTime() {
        Collections.sort(callList, Comparator.comparing(EmergencyCall::getTimestamp));
    }

    // Αποθήκευση σε αρχείο CSV
    public void saveCallsToCSV(String filename) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename))) {
            for (EmergencyCall call : callList) {
                pw.println(serializeCall(call));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Φόρτωση από CSV
    public void loadCallsFromCSV(String filename) {
        File file = new File(filename);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                EmergencyCall call = CallSerializer.deserialize(line);
                if (call != null) callList.add(call);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String serializeCall(EmergencyCall call) {
        // Χωρισμός τιμών με ;
        return call.getId() + ";" +
                call.getCaller().getFullName() + ";" +
                call.getCaller().getPhoneNumber() + ";" +
                call.getDescription() + ";" +
                call.getServices().toString().replaceAll("[\\[\\]\\s]", "") + ";" +
                call.getStatus() + ";" +
                call.getTimestamp();
    }
}

package controller;

import model.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UserLoader {

    public static List<User> loadUsers(String filename) {
        List<User> users = new ArrayList<>();
        File file = new File(filename);

        if (!file.exists()) return users;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 4) {
                    String username = parts[0];
                    String password = parts[1];
                    String fullName = parts[2];
                    String phone = parts[3];

                    if (username.equals("admin")) {
                        users.add(new Admin(username, password));
                    } else {
                        users.add(new Citizen(username, password, fullName, phone));
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return users;
    }
}

package gui;

import model.*;
import controller.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.List;

public class RegistrationForm extends JFrame {
    private JTextField usernameField, fullNameField, phoneField;
    private JPasswordField passwordField;
    private JButton registerButton, backButton;

    private List<User> users;

    public RegistrationForm(List<User> users) {
        this.users = users;

        setTitle("Εγγραφή Νέου Χρήστη");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(6, 2, 5, 5));

        add(new JLabel("Όνομα χρήστη:"));
        usernameField = new JTextField();
        add(usernameField);

        add(new JLabel("Κωδικός:"));
        passwordField = new JPasswordField();
        add(passwordField);

        add(new JLabel("Ονοματεπώνυμο:"));
        fullNameField = new JTextField();
        add(fullNameField);

        add(new JLabel("Τηλέφωνο (10ψήφιο):"));
        phoneField = new JTextField();
        add(phoneField);

        registerButton = new JButton("Εγγραφή");
        backButton = new JButton("🏠 Αρχική Σελίδα");
        add(registerButton);
        add(backButton);

        registerButton.addActionListener(e -> register());

        backButton.addActionListener(e -> {
            dispose();
            List<User> userList = controller.UserLoader.loadUsers("data/users.csv");
            new LoginForm(userList);
        });

        setVisible(true);
    }

    private void register() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String fullName = fullNameField.getText().trim();
        String phone = phoneField.getText().trim();

        if (username.isEmpty() || password.isEmpty() || fullName.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Συμπλήρωσε όλα τα πεδία!");
            return;
        }

        if (!phone.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "Το τηλέφωνο πρέπει να έχει ακριβώς 10 αριθμούς.");
            return;
        }

        for (User u : users) {
            if (u.getUsername().equals(username)) {
                JOptionPane.showMessageDialog(this, "Το όνομα χρήστη υπάρχει ήδη.");
                return;
            }
            if (u instanceof Citizen) {
                Citizen c = (Citizen) u;
                if (c.getFullName().equalsIgnoreCase(fullName)) {
                    JOptionPane.showMessageDialog(this, "Υπάρχει ήδη χρήστης με το ίδιο ονοματεπώνυμο.");
                    return;
                }
                if (c.getPhoneNumber().equals(phone)) {
                    JOptionPane.showMessageDialog(this, "Ο αριθμός τηλεφώνου χρησιμοποιείται ήδη.");
                    return;
                }
            }
        }

        Citizen citizen = new Citizen(username, password, fullName, phone);
        users.add(citizen);
        saveUserToCSV(citizen);

        JOptionPane.showMessageDialog(this, "Επιτυχής εγγραφή!");
        new LoginForm(users);
        dispose();
    }

    private void saveUserToCSV(Citizen user) {
        try (PrintWriter pw = new PrintWriter(new FileWriter("data/users.csv", true))) {
            pw.println(user.getUsername() + ";" +
                       user.getPassword() + ";" +
                       user.getFullName() + ";" +
                       user.getPhoneNumber());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

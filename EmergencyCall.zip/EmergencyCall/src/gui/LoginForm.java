package gui;

import model.*;
import controller.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class LoginForm extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton, registerButton;

    private List<User> users; // Θα φορτωθεί απ’ το αρχείο

    public LoginForm(List<User> users) {
        this.users = users;

        setTitle("Σύνδεση Χρήστη");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Layout
        setLayout(new GridLayout(4, 2));

        add(new JLabel("Όνομα χρήστη:"));
        usernameField = new JTextField();
        add(usernameField);

        add(new JLabel("Κωδικός πρόσβασης:"));
        passwordField = new JPasswordField();
        add(passwordField);

        loginButton = new JButton("Σύνδεση");
        registerButton = new JButton("Εγγραφή");

        add(loginButton);
        add(registerButton);

        loginButton.addActionListener(e -> login());
        registerButton.addActionListener(e -> openRegistrationForm());

        setVisible(true);
    }

    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        for (User user : users) {
            if (user.login(username, password)) {
                JOptionPane.showMessageDialog(this, "Επιτυχής σύνδεση!");

                if (user instanceof Admin) {
                    new AdminPanel((Admin) user); // Εδώ θα πάει στο admin GUI
                } else if (user instanceof Citizen) {
                    new CitizenPanel((Citizen) user); // Εδώ στο GUI του πολίτη
                }

                dispose();
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Λάθος στοιχεία!");
    }

    private void openRegistrationForm() {
        new RegistrationForm(users);
        dispose();
    }
}

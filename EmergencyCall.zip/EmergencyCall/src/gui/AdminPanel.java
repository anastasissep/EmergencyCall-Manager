package gui;

import model.*;
import controller.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class AdminPanel extends JFrame {
    private Admin admin;
    private CallManager callManager;
    private JTabbedPane tabbedPane;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public AdminPanel(Admin admin) {
        this.admin = admin;
        this.callManager = new CallManager();
        callManager.loadCallsFromCSV("data/calls.csv");

        setTitle("Πάνελ Διαχειριστή - Πλήρης Έκδοση");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel searchPanel = new JPanel(new BorderLayout());
        JTextField searchField = new JTextField();
        JButton searchButton = new JButton("🔍 Αναζήτηση Περιγραφής");

        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);
        add(searchPanel, BorderLayout.NORTH);

        tabbedPane = new JTabbedPane();
        tabbedPane.add("🗂 Όλες οι Κλήσεις", createAllCallsPanel());
        tabbedPane.add("✅ Ολοκληρωμένες", createResolvedPanel());
        for (ServiceType service : ServiceType.values()) {
            tabbedPane.add("🆘 " + service.name(), createServicePanel(service));
        }
        add(tabbedPane, BorderLayout.CENTER);

        JButton homeButton = new JButton("🏠 Αρχική Σελίδα");
        homeButton.addActionListener(e -> {
            dispose();
            List<User> users = UserLoader.loadUsers("data/users.csv");
            new LoginForm(users);
        });
        add(homeButton, BorderLayout.SOUTH);

        searchButton.addActionListener(e -> {
            String keyword = searchField.getText().trim().toLowerCase();
            if (!keyword.isEmpty()) {
                showSearchResults(keyword);
            }
        });

        setVisible(true);
    }

    private JPanel createServicePanel(ServiceType serviceType) {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columns = {"ID", "Πολίτης", "Τηλέφωνο", "Περιγραφή", "Υπηρεσίες", "Ώρα"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);

        List<EmergencyCall> calls = callManager.getCallsByService(serviceType);
        for (EmergencyCall call : calls) {
            model.addRow(new Object[]{
                    call.getId(),
                    call.getCaller().getFullName(),
                    call.getCaller().getPhoneNumber(),
                    call.getDescription(),
                    call.getServices().toString(),
                    formatter.format(call.getTimestamp())
            });
        }

        JButton resolveButton = new JButton("Ολοκλήρωση Επιλεγμένης Κλήσης");
        resolveButton.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected != -1) {
                int callId = (int) model.getValueAt(selected, 0);
                EmergencyCall resolvedCall = null;

                for (EmergencyCall c : callManager.getAllCalls()) {
                    if (c.getId() == callId) {
                        resolvedCall = c;
                        break;
                    }
                }

                if (resolvedCall != null) {
                    callManager.markCallAsResolved(callId);
                    callManager.saveCallsToCSV("data/calls.csv");
                    model.removeRow(selected);

                    JOptionPane.showMessageDialog(this,
                            "Η κλήση #" + resolvedCall.getId() + " ολοκληρώθηκε:\n" +
                            "Περιγραφή: " + resolvedCall.getDescription() + "\n\n" +
                            "Ημερομηνία/Ώρα: " + formatter.format(resolvedCall.getTimestamp()) + "\n" +
                            "Η κλήση αφαιρέθηκε από τη λίστα των ενεργών.",
                            "Αναφορά Κλήσης",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            } else {
                JOptionPane.showMessageDialog(this, "Επίλεξε μια κλήση πρώτα.");
            }
        });

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        panel.add(resolveButton, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createAllCallsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columns = {"ID", "Πολίτης", "Τηλέφωνο", "Περιγραφή", "Υπηρεσίες", "Κατάσταση", "Ώρα"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);

        for (EmergencyCall call : callManager.getAllCalls()) {
            model.addRow(new Object[]{
                    call.getId(),
                    call.getCaller().getFullName(),
                    call.getCaller().getPhoneNumber(),
                    call.getDescription(),
                    call.getServices().toString(),
                    call.getStatus(),
                    formatter.format(call.getTimestamp())
            });
        }

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createResolvedPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columns = {"ID", "Πολίτης", "Περιγραφή", "Υπηρεσίες", "Ώρα"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);

        for (EmergencyCall call : callManager.getAllCalls()) {
            if (call.getStatus() == CallStatus.RESOLVED) {
                model.addRow(new Object[]{
                        call.getId(),
                        call.getCaller().getFullName(),
                        call.getDescription(),
                        call.getServices().toString(),
                        formatter.format(call.getTimestamp())
                });
            }
        }

        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private void showSearchResults(String keyword) {
        JPanel resultPanel = new JPanel(new BorderLayout());
        String[] columns = {"ID", "Πολίτης", "Περιγραφή", "Υπηρεσίες", "Κατάσταση", "Ώρα"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);

        for (EmergencyCall c : callManager.getAllCalls()) {
            if (c.getDescription().toLowerCase().contains(keyword)) {
                model.addRow(new Object[]{
                        c.getId(),
                        c.getCaller().getFullName(),
                        c.getDescription(),
                        c.getServices(),
                        c.getStatus(),
                        formatter.format(c.getTimestamp())
                });
            }
        }

        resultPanel.add(new JScrollPane(table), BorderLayout.CENTER);
        tabbedPane.add("🔍 Αποτελέσματα: " + keyword, resultPanel);
        tabbedPane.setSelectedComponent(resultPanel);
    }
}

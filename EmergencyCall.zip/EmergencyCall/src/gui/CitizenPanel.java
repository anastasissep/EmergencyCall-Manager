package gui;

import model.*;
import controller.*;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class CitizenPanel extends JFrame {
    private Citizen citizen;
    private JTextArea descriptionArea;
    private JCheckBox fireCheckBox, policeCheckBox, ambulanceCheckBox;
    private JButton submitButton;

    private CallManager callManager;

    public CitizenPanel(Citizen citizen) {
        this.citizen = citizen;
        this.callManager = new CallManager();
        callManager.loadCallsFromCSV("data/calls.csv");

        setTitle("Καταγραφή Κλήσης Πολίτη");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        descriptionArea = new JTextArea("Περιγραφή περιστατικού...");
        inputPanel.add(new JScrollPane(descriptionArea));

        JPanel checkPanel = new JPanel();
        fireCheckBox = new JCheckBox("Πυροσβεστική");
        policeCheckBox = new JCheckBox("Αστυνομία");
        ambulanceCheckBox = new JCheckBox("Ασθενοφόρο");

        checkPanel.add(fireCheckBox);
        checkPanel.add(policeCheckBox);
        checkPanel.add(ambulanceCheckBox);
        inputPanel.add(checkPanel);

        submitButton = new JButton("Καταχώριση Κλήσης");
        inputPanel.add(submitButton);

        // 🏠 Κουμπί επιστροφής στην αρχική σελίδα
        JButton backButton = new JButton("🏠 Αρχική Σελίδα");
        backButton.addActionListener(e -> {
            dispose();
            List<User> users = controller.UserLoader.loadUsers("data/users.csv");
            new LoginForm(users);
        });
        inputPanel.add(backButton);

        add(inputPanel, BorderLayout.CENTER);

        submitButton.addActionListener(e -> submitCall());

        setVisible(true);
    }

    private void submitCall() {
        String description = descriptionArea.getText().trim();
        List<ServiceType> selectedServices = new ArrayList<>();

        if (fireCheckBox.isSelected()) selectedServices.add(ServiceType.ΠΥΡΟΣΒΕΣΤΙΚΗ);
        if (policeCheckBox.isSelected()) selectedServices.add(ServiceType.ΑΣΤΥΝΟΜΙΑ);
        if (ambulanceCheckBox.isSelected()) selectedServices.add(ServiceType.ΑΣΘΕΝΟΦΟΡΟ);

        if (description.isEmpty() || selectedServices.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Συμπλήρωσε περιγραφή και επέλεξε τουλάχιστον μία υπηρεσία.");
            return;
        }

        EmergencyCall newCall = citizen.makeEmergencyCall(description, selectedServices);
        callManager.addCall(newCall);
        callManager.saveCallsToCSV("data/calls.csv");

        JOptionPane.showMessageDialog(this, "Η κλήση καταχωρήθηκε!");
        descriptionArea.setText("");
        fireCheckBox.setSelected(false);
        policeCheckBox.setSelected(false);
        ambulanceCheckBox.setSelected(false);
    }
}

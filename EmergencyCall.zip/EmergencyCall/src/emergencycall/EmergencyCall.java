package emergencycall;

import gui.LoginForm;
import controller.UserLoader;
import controller.FileInitializer;
import model.User;

import java.util.List;

public class EmergencyCall {

    public static void main(String[] args) {
        // Δημιουργεί τα αρχεία users.csv & calls.csv αν δεν υπάρχουν
        FileInitializer.initializeDataFiles();

        // Φορτώνει όλους τους χρήστες (admin + citizens)
        List<User> users = UserLoader.loadUsers("data/users.csv");

        // Εκκίνηση της εφαρμογής με φόρμα login
        LoginForm loginForm = new LoginForm(users);
    }
    
}

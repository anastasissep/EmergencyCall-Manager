package model;

import java.io.Serializable;

public abstract class User implements Serializable {
    protected String username;
    protected String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Μέθοδος login - έλεγχος username/password (overridable αν χρειαστεί)
    public boolean login(String inputUsername, String inputPassword) {
        return this.username.equals(inputUsername) && this.password.equals(inputPassword);
    }

    // Μέθοδος εγγραφής - τα δεδομένα αποθηκεύονται εξωτερικά (handled elsewhere)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Κάθε υποκλάση υλοποιεί το dashboard της
    public abstract void viewDashboard();
}

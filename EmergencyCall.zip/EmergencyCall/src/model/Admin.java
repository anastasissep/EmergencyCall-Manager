package model;

import java.util.List;

public class Admin extends User {

    public Admin(String username, String password) {
        super(username, password);
    }

    // Εμφανίζει όλες τις κλήσεις (εδώ placeholder, στη GUI μορφή θα καλέσει GUI παράθυρο)
    public void viewAllCalls(List<EmergencyCall> calls) {
        for (EmergencyCall call : calls) {
            System.out.println(call);
        }
    }

    // Μαρκάρει μια κλήση ως επιλυμένη
    public void markCallAsResolved(EmergencyCall call) {
        call.setStatus(CallStatus.RESOLVED);
    }

    @Override
    public void viewDashboard() {
        System.out.println("Admin Dashboard - Διαχείριση κλήσεων.");
    }
}

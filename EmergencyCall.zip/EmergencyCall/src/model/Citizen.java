package model;

import java.util.List;

public class Citizen extends User {
    private String fullName;
    private String phoneNumber;

    public Citizen(String username, String password, String fullName, String phoneNumber) {
        super(username, password);
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
    }

    // Δημιουργία νέας κλήσης
    public EmergencyCall makeEmergencyCall(String description, List<ServiceType> services) {
        return new EmergencyCall(this, description, services);
    }

    @Override
    public void viewDashboard() {
        // Εδώ μπορεί να ανοίγει το παράθυρο υποβολής νέας κλήσης
        System.out.println("Citizen Dashboard - Υποβολή νέας κλήσης.");
    }

    // Getters και setters
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}

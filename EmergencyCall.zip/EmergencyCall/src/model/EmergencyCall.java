package model;

import java.time.LocalDateTime;
import java.util.List;

public class EmergencyCall {
    private static int counter = 0;  // Για μοναδικά IDs
    private int id;
    private Citizen caller;
    private String description;
    private List<ServiceType> services;
    private CallStatus status;
    private LocalDateTime timestamp;

    public EmergencyCall(Citizen caller, String description, List<ServiceType> services) {
        this.id = ++counter;
        this.caller = caller;
        this.description = description;
        this.services = services;
        this.status = CallStatus.PENDING;
        this.timestamp = LocalDateTime.now();
    }

    // Getters και Setters
    public int getId() {
        return id;
    }

    public Citizen getCaller() {
        return caller;
    }

    public String getDescription() {
        return description;
    }

    public List<ServiceType> getServices() {
        return services;
    }

    public CallStatus getStatus() {
        return status;
    }

    public void setStatus(CallStatus status) {
        this.status = status;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return "Κλήση #" + id + " από " + caller.getFullName() +
                " [" + caller.getPhoneNumber() + "] - " +
                "Περιγραφή: " + description + " - " +
                "Υπηρεσίες: " + services + " - " +
                "Κατάσταση: " + status + " - " +
                "Ώρα: " + timestamp;
    }
}

package model;

public enum ServiceType {
    ΠΥΡΟΣΒΕΣΤΙΚΗ,
    ΑΣΤΥΝΟΜΙΑ,
    ΑΣΘΕΝΟΦΟΡΟ
}

package model;

public enum CallStatus {
    PENDING,
    RESOLVED
}
